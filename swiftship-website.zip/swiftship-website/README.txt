SWIFTSHIP WEBSITE PROTOTYPE

Files:
- index.html: responsive single-page website

IMPORTANT BEFORE PUBLISHING
1. Replace YOUR-BUSINESS-EMAIL@example.com in the contact section and in the businessEmail variable in the script with your real business email.
2. Replace the placeholder phone number and service area with accurate details.
3. The tracking widget is a demo only; it does not query a real carrier.
4. The quote form prepares an email through the visitor's email app; it is not a hosted form backend.
5. Do not advertise delivery services, guarantees, tracking, or prices you cannot actually provide.

FREE PUBLISHING OPTION: GITHUB PAGES
1. Create/sign in to a GitHub account at https://github.com
2. Create a new public repository named swiftship-website.
3. Upload index.html (and optionally this README.txt) to the repository root.
4. Open repository Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Choose branch main and folder /(root), then Save.
7. Wait for the published URL shown on the Pages settings screen. It will usually look like https://YOUR-USERNAME.github.io/swiftship-website/
8. Open the link on your phone and computer to test it.

ALTERNATIVE: NETLIFY DROP
Visit https://app.netlify.com/drop and drag the folder containing index.html into the drop area if that workflow is available to your account. Netlify will provide a preview URL. Check current plan limits and terms.

This is a static website. Live shipment tracking, automated quote collection, databases, secure customer accounts, payment processing, a custom domain, and real carrier connections may require extra setup or fees.
